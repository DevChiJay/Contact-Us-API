const nodemailer = require('nodemailer');

// create reusable transporter object using the default SMTP transport
const transporter = nodemailer.createTransport({
  host: 'mail.justcorrupt.tech',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'noreply@justcorrupt.tech',
    pass: 'gold4all',
  },
  tls: {
    rejectUnauthorized: false,
  },
});

module.exports = transporter;
